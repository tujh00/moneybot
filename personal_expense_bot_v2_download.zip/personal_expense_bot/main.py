from __future__ import annotations

import asyncio
import logging
import os
import sqlite3
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from aiogram import Bot, Dispatcher, F, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
)
from aiogram.exceptions import TelegramBadRequest
from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DB_PATH = Path(os.getenv("DB_PATH", str(BASE_DIR / "expenses.db")))
TIMEZONE_NAME = os.getenv("TIMEZONE", "Europe/Helsinki")
PAGE_SIZE = 8

try:
    LOCAL_TZ = ZoneInfo(TIMEZONE_NAME)
except ZoneInfoNotFoundError:
    logging.warning("Unknown TIMEZONE=%s; using UTC", TIMEZONE_NAME)
    LOCAL_TZ = ZoneInfo("UTC")


CATEGORIES: dict[str, list[tuple[str, str]]] = {
    "income": [
        ("💼 Работа", "work"),
        ("🎁 Подарок", "gift"),
        ("🤝 Долг", "debt"),
        ("🎓 Стипендия", "scholarship"),
    ],
    "expense": [
        ("🛒 Магазины", "shops"),
        ("🎮 Развлечения", "entertainment"),
        ("🏠 Дом", "home"),
        ("🩺 Здоровье", "health"),
        ("🚌 Транспорт", "transport"),
        ("🍽️ Кафе и рестораны", "restaurants"),
        ("👕 Шоппинг", "shopping"),
    ],
}

WALLETS: list[tuple[str, str]] = [
    ("💵 Наличка", "cash"),
    ("💳 Карта", "card"),
    ("💳 Кредитка", "credit_card"),
    ("🏦 Накопительный счёт", "savings"),
]

KIND_LABELS = {"income": "Доход", "expense": "Расход"}
CATEGORY_LABELS = {code: label for values in CATEGORIES.values() for label, code in values}
WALLET_LABELS = {code: label for label, code in WALLETS}
INCOME_BUTTON = "💰 Доходы"
EXPENSE_BUTTON = "🧾 Расходы"
STATS_BUTTON = "📊 Моя статистика"


class TransactionForm(StatesGroup):
    amount = State()
    category = State()
    wallet = State()


class TransactionEditForm(StatesGroup):
    amount = State()
    category = State()
    wallet = State()
    occurred_on = State()


class BalanceForm(StatesGroup):
    amount = State()


router = Router()


# ----------------------------- Database ----------------------------------
def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def db_timestamp() -> str:
    """UTC timestamp in a lexicographically sortable SQLite-friendly format."""
    return datetime.now(timezone.utc).replace(tzinfo=None).strftime("%Y-%m-%d %H:%M:%S.%f")


def init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                kind TEXT NOT NULL CHECK(kind IN ('income', 'expense')),
                amount_minor INTEGER NOT NULL CHECK(amount_minor > 0),
                category TEXT NOT NULL,
                wallet TEXT NOT NULL,
                occurred_on TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_transactions_user_date "
            "ON transactions(user_id, occurred_on)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_transactions_user_created "
            "ON transactions(user_id, created_at)"
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS wallet_balances (
                user_id INTEGER NOT NULL,
                wallet TEXT NOT NULL,
                balance_minor INTEGER NOT NULL DEFAULT 0,
                as_of TEXT NOT NULL,
                PRIMARY KEY (user_id, wallet)
            )
            """
        )


def save_transaction(
    user_id: int,
    kind: str,
    amount_minor: int,
    category: str,
    wallet: str,
    occurred_on: date,
) -> int:
    with get_connection() as conn:
        cursor = conn.execute(
            """INSERT INTO transactions
               (user_id, kind, amount_minor, category, wallet, occurred_on, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (user_id, kind, amount_minor, category, wallet, occurred_on.isoformat(), db_timestamp()),
        )
        return int(cursor.lastrowid)


def get_transaction(user_id: int, transaction_id: int) -> sqlite3.Row | None:
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM transactions WHERE id = ? AND user_id = ?",
            (transaction_id, user_id),
        ).fetchone()


def count_transactions(user_id: int) -> int:
    with get_connection() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS n FROM transactions WHERE user_id = ?", (user_id,)
        ).fetchone()
        return int(row["n"])


def list_transactions(user_id: int, page: int, page_size: int = PAGE_SIZE) -> list[sqlite3.Row]:
    page = max(0, page)
    with get_connection() as conn:
        return conn.execute(
            """SELECT * FROM transactions WHERE user_id = ?
               ORDER BY occurred_on DESC, id DESC LIMIT ? OFFSET ?""",
            (user_id, page_size, page * page_size),
        ).fetchall()


def update_transaction(user_id: int, transaction_id: int, field: str, value: object) -> bool:
    allowed_fields = {"amount_minor", "category", "wallet", "occurred_on"}
    if field not in allowed_fields:
        raise ValueError("Недопустимое поле транзакции")
    with get_connection() as conn:
        cursor = conn.execute(
            f"UPDATE transactions SET {field} = ? WHERE id = ? AND user_id = ?",
            (value, transaction_id, user_id),
        )
        return cursor.rowcount > 0


def delete_transaction(user_id: int, transaction_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.execute(
            "DELETE FROM transactions WHERE id = ? AND user_id = ?",
            (transaction_id, user_id),
        )
        return cursor.rowcount > 0


def set_wallet_balance(user_id: int, wallet: str, balance_minor: int) -> None:
    # The entered balance is the real balance at this moment. Only transactions
    # recorded after this timestamp affect the balance, avoiding double-counting
    # old history when a user first configures balances.
    with get_connection() as conn:
        conn.execute(
            """INSERT INTO wallet_balances (user_id, wallet, balance_minor, as_of)
               VALUES (?, ?, ?, ?)
               ON CONFLICT(user_id, wallet) DO UPDATE SET
                   balance_minor = excluded.balance_minor,
                   as_of = excluded.as_of""",
            (user_id, wallet, balance_minor, db_timestamp()),
        )


def wallet_balance_summary(user_id: int) -> dict[str, dict[str, int | str | None]]:
    with get_connection() as conn:
        base_rows = conn.execute(
            "SELECT wallet, balance_minor, as_of FROM wallet_balances WHERE user_id = ?",
            (user_id,),
        ).fetchall()
        bases = {row["wallet"]: row for row in base_rows}
        movements: dict[tuple[str, str], int] = {}
        for row in conn.execute(
            """SELECT t.wallet, t.kind, COALESCE(SUM(t.amount_minor), 0) AS total
               FROM transactions t
               LEFT JOIN wallet_balances b
                 ON b.user_id = t.user_id AND b.wallet = t.wallet
               WHERE t.user_id = ? AND (b.as_of IS NULL OR t.created_at > b.as_of)
               GROUP BY t.wallet, t.kind""",
            (user_id,),
        ).fetchall():
            movements[(row["wallet"], row["kind"])] = int(row["total"] or 0)

    result: dict[str, dict[str, int | str | None]] = {}
    for _, wallet in WALLETS:
        base = bases.get(wallet)
        opening = int(base["balance_minor"]) if base else 0
        income = movements.get((wallet, "income"), 0)
        expense = movements.get((wallet, "expense"), 0)
        result[wallet] = {
            "opening": opening,
            "current": opening + income - expense,
            "as_of": base["as_of"] if base else None,
        }
    return result


def month_summary(user_id: int, month_key: str) -> dict:
    start = date.fromisoformat(f"{month_key}-01")
    next_month = date(start.year + 1, 1, 1) if start.month == 12 else date(start.year, start.month + 1, 1)

    with get_connection() as conn:
        totals = {
            row["kind"]: row["total"]
            for row in conn.execute(
                """SELECT kind, COALESCE(SUM(amount_minor), 0) AS total
                   FROM transactions
                   WHERE user_id = ? AND occurred_on >= ? AND occurred_on < ?
                   GROUP BY kind""",
                (user_id, start.isoformat(), next_month.isoformat()),
            ).fetchall()
        }
        by_category = {
            (row["kind"], row["category"]): row["total"]
            for row in conn.execute(
                """SELECT kind, category, SUM(amount_minor) AS total
                   FROM transactions
                   WHERE user_id = ? AND occurred_on >= ? AND occurred_on < ?
                   GROUP BY kind, category""",
                (user_id, start.isoformat(), next_month.isoformat()),
            ).fetchall()
        }
        by_wallet = {
            (row["wallet"], row["kind"]): row["total"]
            for row in conn.execute(
                """SELECT wallet, kind, SUM(amount_minor) AS total
                   FROM transactions
                   WHERE user_id = ? AND occurred_on >= ? AND occurred_on < ?
                   GROUP BY wallet, kind""",
                (user_id, start.isoformat(), next_month.isoformat()),
            ).fetchall()
        }
    return {
        "income": totals.get("income", 0),
        "expense": totals.get("expense", 0),
        "by_category": by_category,
        "by_wallet": by_wallet,
    }


# ----------------------------- Keyboards ---------------------------------
def main_menu_keyboard() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=INCOME_BUTTON), KeyboardButton(text=EXPENSE_BUTTON)],
            [KeyboardButton(text=STATS_BUTTON)],
        ],
        resize_keyboard=True,
        input_field_placeholder="Выберите действие",
    )


def category_keyboard(kind: str, callback_prefix: str = "cat") -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    current_row: list[InlineKeyboardButton] = []
    for label, code in CATEGORIES[kind]:
        current_row.append(InlineKeyboardButton(text=label, callback_data=f"{callback_prefix}:{code}"))
        if len(current_row) == 2:
            rows.append(current_row)
            current_row = []
    if current_row:
        rows.append(current_row)
    rows.append([InlineKeyboardButton(text="✖️ Отмена", callback_data="txn:cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def wallet_keyboard(callback_prefix: str = "wallet") -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=label, callback_data=f"{callback_prefix}:{code}")] for label, code in WALLETS]
    rows.append([InlineKeyboardButton(text="✖️ Отмена", callback_data="txn:cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def stats_keyboard(month_key: str) -> InlineKeyboardMarkup:
    selected = date.fromisoformat(f"{month_key}-01")
    today = datetime.now(LOCAL_TZ).date()
    current_month = date(today.year, today.month, 1)
    previous = date(selected.year - 1, 12, 1) if selected.month == 1 else date(selected.year, selected.month - 1, 1)
    nav_row = [InlineKeyboardButton(text="◀️ Предыдущий месяц", callback_data=f"month:{previous.year:04d}-{previous.month:02d}")]
    if selected < current_month:
        next_month = date(selected.year + 1, 1, 1) if selected.month == 12 else date(selected.year, selected.month + 1, 1)
        if next_month <= current_month:
            nav_row.append(InlineKeyboardButton(text="Следующий месяц ▶️", callback_data=f"month:{next_month.year:04d}-{next_month.month:02d}"))
    return InlineKeyboardMarkup(inline_keyboard=[
        nav_row,
        [InlineKeyboardButton(text="📋 Последние операции", callback_data=f"txl:0:{month_key}"), InlineKeyboardButton(text="🏦 Балансы", callback_data=f"bal:{month_key}")],
        [InlineKeyboardButton(text="↩️ Вернуться назад", callback_data="nav:back")],
    ])


def transactions_keyboard(page: int, month_key: str, total: int, rows: list[sqlite3.Row]) -> InlineKeyboardMarkup:
    keyboard: list[list[InlineKeyboardButton]] = []
    for tx in rows:
        kind_icon = "📥" if tx["kind"] == "income" else "📤"
        label = f"{date.fromisoformat(tx['occurred_on']).strftime('%d.%m')} · {kind_icon} {format_money(int(tx['amount_minor']))} · {CATEGORY_LABELS.get(tx['category'], tx['category'])}"
        if len(label) > 62:
            label = label[:59] + "…"
        keyboard.append([InlineKeyboardButton(text=label, callback_data=f"txv:{tx['id']}:{page}:{month_key}")])
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️ Новее", callback_data=f"txl:{page - 1}:{month_key}"))
    if (page + 1) * PAGE_SIZE < total:
        nav.append(InlineKeyboardButton(text="Старее ▶️", callback_data=f"txl:{page + 1}:{month_key}"))
    if nav:
        keyboard.append(nav)
    keyboard.append([InlineKeyboardButton(text="🏦 Балансы", callback_data=f"bal:{month_key}")])
    keyboard.append([InlineKeyboardButton(text="↩️ К статистике", callback_data=f"statsback:{month_key}")])
    return InlineKeyboardMarkup(inline_keyboard=keyboard)


def transaction_detail_keyboard(transaction_id: int, page: int, month_key: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Сумма", callback_data=f"txea:{transaction_id}:{page}:{month_key}"), InlineKeyboardButton(text="🗂 Категория", callback_data=f"txec:{transaction_id}:{page}:{month_key}")],
        [InlineKeyboardButton(text="💳 Счёт / оплата", callback_data=f"txew:{transaction_id}:{page}:{month_key}"), InlineKeyboardButton(text="📅 Дата", callback_data=f"txed:{transaction_id}:{page}:{month_key}")],
        [InlineKeyboardButton(text="🗑 Удалить", callback_data=f"txdel:{transaction_id}:{page}:{month_key}")],
        [InlineKeyboardButton(text="↩️ К списку", callback_data=f"txl:{page}:{month_key}")],
    ])


def balance_keyboard(month_key: str) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=f"Изменить: {label}", callback_data=f"bale:{wallet}:{month_key}")] for label, wallet in WALLETS]
    rows.append([InlineKeyboardButton(text="↩️ К статистике", callback_data=f"statsback:{month_key}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def delete_confirmation_keyboard(transaction_id: int, page: int, month_key: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Да, удалить", callback_data=f"txdc:{transaction_id}:{page}:{month_key}"), InlineKeyboardButton(text="Нет, оставить", callback_data=f"txv:{transaction_id}:{page}:{month_key}")]
    ])


# ----------------------------- Formatting --------------------------------
def format_money(amount_minor: int) -> str:
    sign = "−" if amount_minor < 0 else ""
    amount_minor = abs(amount_minor)
    rubles, kopecks = divmod(amount_minor, 100)
    rubles_text = f"{rubles:,}".replace(",", " ")
    return f"{sign}{rubles_text},{kopecks:02d} ₽" if kopecks else f"{sign}{rubles_text} ₽"


def _parse_decimal_minor(text: str) -> int:
    normalized = (text.strip().replace("₽", "").replace("руб.", "").replace("руб", "")
                  .replace(" ", "").replace("\u00a0", "").replace(",", "."))
    try:
        amount = Decimal(normalized)
    except (InvalidOperation, ValueError):
        raise ValueError("Не получилось распознать сумму.")
    if not amount.is_finite():
        raise ValueError("Введите корректную сумму.")
    if amount.as_tuple().exponent < -2:
        raise ValueError("Можно указать не больше двух знаков после запятой.")
    amount_minor = int(amount * 100)
    if abs(amount_minor) > 100_000_000_000_000:
        raise ValueError("Сумма слишком большая.")
    return amount_minor


def parse_amount(text: str) -> int:
    amount_minor = _parse_decimal_minor(text)
    if amount_minor <= 0:
        raise ValueError("Сумма должна быть больше нуля.")
    return amount_minor


def parse_balance_amount(text: str) -> int:
    # Zero is valid; negative values are useful for an outstanding credit-card debt.
    return _parse_decimal_minor(text)


def month_title(month_key: str) -> str:
    names = ["январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"]
    month = date.fromisoformat(f"{month_key}-01")
    return f"{names[month.month - 1].capitalize()} {month.year}"


def build_stats_text(user_id: int, month_key: str) -> str:
    summary = month_summary(user_id, month_key)
    income, expense = summary["income"], summary["expense"]
    balance = income - expense
    balance_prefix = "+" if balance > 0 else ("−" if balance < 0 else "")
    lines = [f"📊 <b>Статистика за {month_title(month_key)}</b>", "", f"💰 <b>Доходы всего: {format_money(income)}</b>"]
    for label, code in CATEGORIES["income"]:
        lines.append(f"  {label} — {format_money(summary['by_category'].get(('income', code), 0))}")
    lines.extend(["", f"🧾 <b>Расходы всего: {format_money(expense)}</b>"])
    for label, code in CATEGORIES["expense"]:
        lines.append(f"  {label} — {format_money(summary['by_category'].get(('expense', code), 0))}")
    lines.extend(["", f"💹 <b>Сальдо: {balance_prefix}{format_money(abs(balance))}</b>", "", "🏦 <b>Движение по способу хранения / оплаты за месяц</b>"])
    for wallet_label, wallet_code in WALLETS:
        wallet_income = summary["by_wallet"].get((wallet_code, "income"), 0)
        wallet_expense = summary["by_wallet"].get((wallet_code, "expense"), 0)
        lines.append(f"  {wallet_label}: +{format_money(wallet_income)} / −{format_money(wallet_expense)}")
    return "\n".join(lines)


def build_transactions_text(user_id: int, page: int, month_key: str) -> tuple[str, InlineKeyboardMarkup]:
    total = count_transactions(user_id)
    rows = list_transactions(user_id, page)
    max_page = max(0, (total - 1) // PAGE_SIZE)
    page = min(max(page, 0), max_page)
    rows = list_transactions(user_id, page)
    if total == 0:
        text = "📋 <b>Транзакции</b>\n\nПока нет ни одной операции. Добавь доход или расход через главное меню."
    else:
        text = f"📋 <b>Операции</b> · страница {page + 1} из {max_page + 1}\nВыбери операцию, чтобы изменить её или удалить.\n\nВсего записей: {total}"
    return text, transactions_keyboard(page, month_key, total, rows)


def transaction_detail_text(tx: sqlite3.Row) -> str:
    kind_icon = "📥" if tx["kind"] == "income" else "📤"
    return (
        f"🧾 <b>Операция №{tx['id']}</b>\n\n"
        f"Тип: {kind_icon} {KIND_LABELS[tx['kind']]}\n"
        f"Сумма: <b>{format_money(int(tx['amount_minor']))}</b>\n"
        f"Категория: {CATEGORY_LABELS.get(tx['category'], tx['category'])}\n"
        f"Счёт / способ оплаты: {WALLET_LABELS.get(tx['wallet'], tx['wallet'])}\n"
        f"Дата: {date.fromisoformat(tx['occurred_on']).strftime('%d.%m.%Y')}\n\n"
        "Что нужно изменить?"
    )


def build_balance_text(user_id: int, month_key: str) -> str:
    balances = wallet_balance_summary(user_id)
    lines = ["🏦 <b>Балансы счетов</b>", "", "Текущий остаток = баланс при установке + операции, записанные после установки.", ""]
    for label, wallet in WALLETS:
        data = balances[wallet]
        lines.append(f"<b>{label}</b>")
        lines.append(f"  Базовый остаток: {format_money(int(data['opening']))}")
        lines.append(f"  <b>Текущий расчётный: {format_money(int(data['current']))}</b>")
        if data["as_of"]:
            try:
                as_of_dt = datetime.strptime(str(data["as_of"]), "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc).astimezone(LOCAL_TZ)
                lines.append(f"  Остаток установлен: {as_of_dt.strftime('%d.%m.%Y %H:%M')}")
            except ValueError:
                lines.append("  Остаток установлен ранее")
        lines.append("")
    lines.append("Для кредитки отрицательный баланс означает долг. При установке остатка старые операции не учитываются повторно; следующие операции автоматически изменяют баланс.")
    return "\n".join(lines)


# ----------------------------- Display helpers ---------------------------
async def display_stats_message(message: Message, user_id: int, month_key: str) -> None:
    await message.answer(build_stats_text(user_id, month_key), reply_markup=stats_keyboard(month_key))


async def display_stats_callback(callback: CallbackQuery, month_key: str) -> None:
    if not callback.message:
        await callback.answer()
        return
    try:
        await callback.message.edit_text(build_stats_text(callback.from_user.id, month_key), reply_markup=stats_keyboard(month_key))
    except TelegramBadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            raise
    await callback.answer()


async def display_transactions_message(message: Message, user_id: int, page: int, month_key: str) -> None:
    text, keyboard = build_transactions_text(user_id, page, month_key)
    await message.answer(text, reply_markup=keyboard)


async def display_transactions_callback(callback: CallbackQuery, page: int, month_key: str) -> None:
    if not callback.message:
        await callback.answer()
        return
    text, keyboard = build_transactions_text(callback.from_user.id, page, month_key)
    try:
        await callback.message.edit_text(text, reply_markup=keyboard)
    except TelegramBadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            raise
    await callback.answer()


async def display_transaction_detail_callback(callback: CallbackQuery, transaction_id: int, page: int, month_key: str) -> None:
    if not callback.message:
        await callback.answer()
        return
    tx = get_transaction(callback.from_user.id, transaction_id)
    if not tx:
        if callback.message:
            text, keyboard = build_transactions_text(callback.from_user.id, page, month_key)
            try:
                await callback.message.edit_text(text, reply_markup=keyboard)
            except TelegramBadRequest as exc:
                if "message is not modified" not in str(exc).lower():
                    raise
        await callback.answer("Операция не найдена.", show_alert=True)
        return
    try:
        await callback.message.edit_text(transaction_detail_text(tx), reply_markup=transaction_detail_keyboard(transaction_id, page, month_key))
    except TelegramBadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            raise
    await callback.answer()


async def display_balances_callback(callback: CallbackQuery, month_key: str) -> None:
    if not callback.message:
        await callback.answer()
        return
    try:
        await callback.message.edit_text(build_balance_text(callback.from_user.id, month_key), reply_markup=balance_keyboard(month_key))
    except TelegramBadRequest as exc:
        if "message is not modified" not in str(exc).lower():
            raise
    await callback.answer()


# ----------------------------- Main handlers ----------------------------
@router.message(CommandStart())
async def command_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Привет! 👋\n\nЯ помогу учитывать личные доходы и расходы. Выбери действие в меню ниже.", reply_markup=main_menu_keyboard())


@router.message(Command("menu"))
async def command_menu(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Главное меню:", reply_markup=main_menu_keyboard())


@router.message(Command("cancel"))
async def command_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Текущая операция отменена.", reply_markup=main_menu_keyboard())


async def begin_transaction(message: Message, state: FSMContext, kind: str) -> None:
    await state.clear()
    await state.update_data(kind=kind)
    await state.set_state(TransactionForm.amount)
    verb = "дохода" if kind == "income" else "расхода"
    await message.answer(f"Введите сумму {verb}.\nНапример: <code>1250</code> или <code>1250,50</code>.", reply_markup=main_menu_keyboard())


@router.message(F.text.in_({INCOME_BUTTON, EXPENSE_BUTTON, STATS_BUTTON}))
async def main_menu_choice(message: Message, state: FSMContext) -> None:
    if message.text == INCOME_BUTTON:
        await begin_transaction(message, state, "income")
    elif message.text == EXPENSE_BUTTON:
        await begin_transaction(message, state, "expense")
    else:
        await state.clear()
        today = datetime.now(LOCAL_TZ).date()
        await display_stats_message(message, message.from_user.id, f"{today.year:04d}-{today.month:02d}")


@router.message(StateFilter(TransactionForm.amount))
async def process_amount(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("Отправь сумму текстом, например <code>1200,50</code>.")
        return
    try:
        amount_minor = parse_amount(message.text)
    except ValueError as exc:
        await message.answer(f"{exc}\nПопробуй ещё раз, например <code>1200,50</code>.")
        return
    data = await state.get_data()
    kind = data.get("kind")
    if kind not in CATEGORIES:
        await state.clear()
        await message.answer("Что-то пошло не так. Начни заново через меню.", reply_markup=main_menu_keyboard())
        return
    await state.update_data(amount_minor=amount_minor)
    await state.set_state(TransactionForm.category)
    prompt = "Выбери категорию дохода:" if kind == "income" else "Выбери категорию расхода:"
    await message.answer(prompt, reply_markup=category_keyboard(kind))


@router.callback_query(StateFilter(TransactionForm.category), F.data.startswith("cat:"))
async def process_category(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    kind = data.get("kind")
    category_code = callback.data.split(":", 1)[1]
    allowed = {code for _, code in CATEGORIES.get(kind, [])}
    if category_code not in allowed:
        await callback.answer("Неизвестная категория", show_alert=True)
        return
    await state.update_data(category=category_code)
    await state.set_state(TransactionForm.wallet)
    if callback.message:
        await callback.message.edit_text(f"Категория: {CATEGORY_LABELS[category_code]}\n\nГде находятся деньги или чем оплачена покупка?", reply_markup=wallet_keyboard())
    await callback.answer()


@router.callback_query(StateFilter(TransactionForm.wallet), F.data.startswith("wallet:"))
async def process_wallet(callback: CallbackQuery, state: FSMContext) -> None:
    wallet_code = callback.data.split(":", 1)[1]
    if wallet_code not in WALLET_LABELS:
        await callback.answer("Неизвестный способ оплаты", show_alert=True)
        return
    data = await state.get_data()
    kind, category_code, amount_minor = data.get("kind"), data.get("category"), data.get("amount_minor")
    if kind not in CATEGORIES or category_code not in CATEGORY_LABELS or not isinstance(amount_minor, int):
        await state.clear()
        await callback.answer("Сессия устарела. Начни заново.", show_alert=True)
        if callback.message:
            await callback.message.answer("Начни заново через меню.", reply_markup=main_menu_keyboard())
        return
    occurred_on = datetime.now(LOCAL_TZ).date()
    save_transaction(callback.from_user.id, kind, amount_minor, category_code, wallet_code, occurred_on)
    await state.clear()
    result = (
        "✅ <b>Транзакция сохранена</b>\n\n"
        f"{'📥 Доход' if kind == 'income' else '📤 Расход'}: {format_money(amount_minor)}\n"
        f"Категория: {CATEGORY_LABELS[category_code]}\n"
        f"Способ: {WALLET_LABELS[wallet_code]}\n"
        f"Дата: {occurred_on.strftime('%d.%m.%Y')}"
    )
    if callback.message:
        try:
            await callback.message.edit_text(result, reply_markup=None)
        except TelegramBadRequest:
            await callback.message.answer(result, reply_markup=main_menu_keyboard())
    await callback.answer("Сохранено")


@router.callback_query(F.data == "txn:cancel")
async def cancel_transaction_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message:
        try:
            await callback.message.edit_reply_markup(reply_markup=None)
        except TelegramBadRequest:
            pass
        await callback.message.answer("Операция отменена.", reply_markup=main_menu_keyboard())
    await callback.answer("Отменено")


@router.callback_query(F.data.startswith("month:"))
async def change_stats_month(callback: CallbackQuery) -> None:
    month_key = callback.data.split(":", 1)[1]
    try:
        selected = date.fromisoformat(f"{month_key}-01")
    except ValueError:
        await callback.answer("Некорректный месяц", show_alert=True)
        return
    today = datetime.now(LOCAL_TZ).date()
    current_month = date(today.year, today.month, 1)
    if selected > current_month:
        month_key = f"{current_month.year:04d}-{current_month.month:02d}"
    await display_stats_callback(callback, month_key)


@router.callback_query(F.data.startswith("txl:"))
async def transactions_list_callback(callback: CallbackQuery) -> None:
    try:
        _, page_text, month_key = callback.data.split(":", 2)
        page = max(0, int(page_text))
        date.fromisoformat(f"{month_key}-01")
    except (ValueError, TypeError):
        await callback.answer("Некорректный запрос", show_alert=True)
        return
    await display_transactions_callback(callback, page, month_key)


@router.callback_query(F.data.startswith("txv:"))
async def transaction_view_callback(callback: CallbackQuery) -> None:
    try:
        _, tx_text, page_text, month_key = callback.data.split(":", 3)
        transaction_id, page = int(tx_text), max(0, int(page_text))
        date.fromisoformat(f"{month_key}-01")
    except (ValueError, TypeError):
        await callback.answer("Некорректная операция", show_alert=True)
        return
    await display_transaction_detail_callback(callback, transaction_id, page, month_key)


async def begin_transaction_edit(callback: CallbackQuery, state: FSMContext, transaction_id: int, page: int, month_key: str, field: str) -> sqlite3.Row | None:
    tx = get_transaction(callback.from_user.id, transaction_id)
    if not tx:
        await callback.answer("Операция не найдена", show_alert=True)
        return None
    await state.clear()
    await state.update_data(edit_tx_id=transaction_id, return_page=page, return_month=month_key, edit_kind=tx["kind"])
    prompts = {
        "amount": (TransactionEditForm.amount, f"Введи новую сумму для операции №{transaction_id}. Например: <code>1500,50</code>"),
        "category": (TransactionEditForm.category, "Выбери новую категорию:"),
        "wallet": (TransactionEditForm.wallet, "Выбери новый счёт / способ оплаты:"),
        "occurred_on": (TransactionEditForm.occurred_on, "Введи новую дату в формате <code>ДД.ММ.ГГГГ</code>, например <code>27.10.2026</code>."),
    }
    target_state, prompt = prompts[field]
    await state.set_state(target_state)
    if callback.message:
        if field == "category":
            await callback.message.edit_text(prompt, reply_markup=category_keyboard(tx["kind"], "txcat"))
        elif field == "wallet":
            await callback.message.edit_text(prompt, reply_markup=wallet_keyboard("txwallet"))
        else:
            await callback.message.edit_text(prompt + "\n\nДля отмены отправь /cancel.", reply_markup=None)
    await callback.answer()
    return tx


@router.callback_query(F.data.startswith("txea:"))
async def transaction_edit_amount_callback(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        _, tx_id, page, month = callback.data.split(":", 3)
        await begin_transaction_edit(callback, state, int(tx_id), int(page), month, "amount")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)


@router.callback_query(F.data.startswith("txec:"))
async def transaction_edit_category_callback(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        _, tx_id, page, month = callback.data.split(":", 3)
        await begin_transaction_edit(callback, state, int(tx_id), int(page), month, "category")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)


@router.callback_query(F.data.startswith("txew:"))
async def transaction_edit_wallet_callback(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        _, tx_id, page, month = callback.data.split(":", 3)
        await begin_transaction_edit(callback, state, int(tx_id), int(page), month, "wallet")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)


@router.callback_query(F.data.startswith("txed:"))
async def transaction_edit_date_callback(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        _, tx_id, page, month = callback.data.split(":", 3)
        await begin_transaction_edit(callback, state, int(tx_id), int(page), month, "occurred_on")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)


async def finish_text_edit(message: Message, state: FSMContext, field: str, value: object) -> None:
    data = await state.get_data()
    tx_id = data.get("edit_tx_id")
    page = int(data.get("return_page", 0))
    month_key = str(data.get("return_month", datetime.now(LOCAL_TZ).strftime("%Y-%m")))
    if not isinstance(tx_id, int) or not update_transaction(message.from_user.id, tx_id, field, value):
        await state.clear()
        await message.answer("Не удалось обновить операцию: возможно, она уже удалена.", reply_markup=main_menu_keyboard())
        return
    await state.clear()
    await message.answer("✅ Операция обновлена.", reply_markup=main_menu_keyboard())
    await display_transactions_message(message, message.from_user.id, page, month_key)


@router.message(StateFilter(TransactionEditForm.amount))
async def process_edit_amount(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("Отправь сумму текстом, например <code>1200,50</code>.")
        return
    try:
        amount = parse_amount(message.text)
    except ValueError as exc:
        await message.answer(f"{exc}\nПопробуй ещё раз.")
        return
    await finish_text_edit(message, state, "amount_minor", amount)


@router.message(StateFilter(TransactionEditForm.occurred_on))
async def process_edit_date(message: Message, state: FSMContext) -> None:
    try:
        parsed_date = datetime.strptime((message.text or "").strip(), "%d.%m.%Y").date()
    except ValueError:
        await message.answer("Не получилось распознать дату. Используй формат <code>ДД.ММ.ГГГГ</code>.")
        return
    if parsed_date > datetime.now(LOCAL_TZ).date():
        await message.answer("Дата операции не может быть в будущем. Введи другую дату.")
        return
    await finish_text_edit(message, state, "occurred_on", parsed_date.isoformat())


@router.callback_query(StateFilter(TransactionEditForm.category), F.data.startswith("txcat:"))
async def process_edit_category(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    code = callback.data.split(":", 1)[1]
    allowed = {code for _, code in CATEGORIES.get(data.get("edit_kind"), [])}
    if code not in allowed:
        await callback.answer("Эта категория не подходит для типа операции", show_alert=True)
        return
    tx_id = data.get("edit_tx_id")
    page, month = int(data.get("return_page", 0)), str(data.get("return_month", datetime.now(LOCAL_TZ).strftime("%Y-%m")))
    if not isinstance(tx_id, int) or not update_transaction(callback.from_user.id, tx_id, "category", code):
        await state.clear()
        await callback.answer("Операция не найдена", show_alert=True)
        return
    await state.clear()
    await display_transaction_detail_callback(callback, tx_id, page, month)


@router.callback_query(StateFilter(TransactionEditForm.wallet), F.data.startswith("txwallet:"))
async def process_edit_wallet(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    wallet = callback.data.split(":", 1)[1]
    if wallet not in WALLET_LABELS:
        await callback.answer("Неизвестный счёт", show_alert=True)
        return
    tx_id = data.get("edit_tx_id")
    page, month = int(data.get("return_page", 0)), str(data.get("return_month", datetime.now(LOCAL_TZ).strftime("%Y-%m")))
    if not isinstance(tx_id, int) or not update_transaction(callback.from_user.id, tx_id, "wallet", wallet):
        await state.clear()
        await callback.answer("Операция не найдена", show_alert=True)
        return
    await state.clear()
    await display_transaction_detail_callback(callback, tx_id, page, month)


@router.callback_query(F.data.startswith("txdel:"))
async def transaction_delete_prompt_callback(callback: CallbackQuery) -> None:
    try:
        _, tx_id, page, month = callback.data.split(":", 3)
        tx_id, page = int(tx_id), max(0, int(page))
        date.fromisoformat(f"{month}-01")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)
        return
    tx = get_transaction(callback.from_user.id, tx_id)
    if not tx:
        await callback.answer("Операция не найдена", show_alert=True)
        return
    if callback.message:
        await callback.message.edit_text(
            f"🗑 <b>Удалить операцию №{tx_id}?</b>\n\n{KIND_LABELS[tx['kind']]}: {format_money(int(tx['amount_minor']))}\n{CATEGORY_LABELS.get(tx['category'], tx['category'])}\nДата: {date.fromisoformat(tx['occurred_on']).strftime('%d.%m.%Y')}\n\nЭто действие нельзя отменить.",
            reply_markup=delete_confirmation_keyboard(tx_id, page, month),
        )
    await callback.answer()


@router.callback_query(F.data.startswith("txdc:"))
async def transaction_delete_confirm_callback(callback: CallbackQuery) -> None:
    try:
        _, tx_id, page, month = callback.data.split(":", 3)
        tx_id, page = int(tx_id), max(0, int(page))
        date.fromisoformat(f"{month}-01")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)
        return
    if not delete_transaction(callback.from_user.id, tx_id):
        await callback.answer("Операция уже удалена или не найдена", show_alert=True)
        return
    if callback.message:
        text, keyboard = build_transactions_text(callback.from_user.id, page, month)
        try:
            await callback.message.edit_text("✅ Операция удалена.\n\n" + text, reply_markup=keyboard)
        except TelegramBadRequest as exc:
            if "message is not modified" not in str(exc).lower():
                raise
    await callback.answer("Операция удалена")


@router.callback_query(F.data.startswith("bal:"))
async def balances_callback(callback: CallbackQuery) -> None:
    month = callback.data.split(":", 1)[1]
    try:
        date.fromisoformat(f"{month}-01")
    except ValueError:
        await callback.answer("Некорректный месяц", show_alert=True)
        return
    await display_balances_callback(callback, month)


@router.callback_query(F.data.startswith("bale:"))
async def balance_edit_callback(callback: CallbackQuery, state: FSMContext) -> None:
    try:
        _, wallet, month = callback.data.split(":", 2)
        date.fromisoformat(f"{month}-01")
    except ValueError:
        await callback.answer("Некорректный запрос", show_alert=True)
        return
    if wallet not in WALLET_LABELS:
        await callback.answer("Неизвестный счёт", show_alert=True)
        return
    await state.clear()
    await state.update_data(balance_wallet=wallet, return_month=month)
    await state.set_state(BalanceForm.amount)
    if callback.message:
        await callback.message.edit_text(
            f"🏦 <b>{WALLET_LABELS[wallet]}</b>\n\n"
            "Введи фактический остаток на счёте сейчас. Можно указать отрицательную сумму, например <code>-12500</code>, если это долг по кредитке. Ноль тоже допустим.\n\n"
            "Это станет точкой отсчёта: операции, сохранённые до установки остатка, повторно учитываться не будут. Последующие доходы и расходы будут менять баланс автоматически.\n\nДля отмены отправь /cancel.",
            reply_markup=None,
        )
    await callback.answer()


@router.message(StateFilter(BalanceForm.amount))
async def process_balance_amount(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("Отправь остаток текстом, например <code>15000</code> или <code>-12500,50</code>.")
        return
    try:
        balance_minor = parse_balance_amount(message.text)
    except ValueError as exc:
        await message.answer(f"{exc}\nПопробуй ещё раз.")
        return
    data = await state.get_data()
    wallet = data.get("balance_wallet")
    month = str(data.get("return_month", datetime.now(LOCAL_TZ).strftime("%Y-%m")))
    if wallet not in WALLET_LABELS:
        await state.clear()
        await message.answer("Счёт не найден. Открой статистику и попробуй ещё раз.", reply_markup=main_menu_keyboard())
        return
    set_wallet_balance(message.from_user.id, wallet, balance_minor)
    await state.clear()
    await message.answer(f"✅ Базовый остаток для «{WALLET_LABELS[wallet]}» установлен: <b>{format_money(balance_minor)}</b>.", reply_markup=main_menu_keyboard())
    # Follow with the refreshed balances panel so the resulting calculation is visible.
    await message.answer(build_balance_text(message.from_user.id, month), reply_markup=balance_keyboard(month))


@router.callback_query(F.data.startswith("statsback:"))
async def stats_back_to_month(callback: CallbackQuery) -> None:
    month = callback.data.split(":", 1)[1]
    try:
        date.fromisoformat(f"{month}-01")
    except ValueError:
        today = datetime.now(LOCAL_TZ).date()
        month = f"{today.year:04d}-{today.month:02d}"
    await display_stats_callback(callback, month)


@router.callback_query(F.data == "nav:back")
async def stats_back(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if callback.message:
        try:
            await callback.message.edit_text("Главное меню. Выбери действие ниже:", reply_markup=None)
        except TelegramBadRequest:
            pass
        await callback.message.answer("Главное меню:", reply_markup=main_menu_keyboard())
    await callback.answer()


@router.message()
async def fallback_message(message: Message) -> None:
    await message.answer("Выбери действие кнопками меню или отправь /start.", reply_markup=main_menu_keyboard())


async def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError("Не найден BOT_TOKEN. Создай файл .env рядом с main.py и добавь строку BOT_TOKEN=твой_токен")
    logging.basicConfig(level=logging.INFO)
    init_db()
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.include_router(router)
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        logging.info("Personal expense bot is starting")
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
